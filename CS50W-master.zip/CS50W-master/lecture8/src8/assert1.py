def square(x):
    return x * x

assert square(10) == 101
