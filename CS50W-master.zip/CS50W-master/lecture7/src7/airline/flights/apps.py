from django.apps import AppConfig


class FlightsConfig(AppConfig):
    name = 'flights'
