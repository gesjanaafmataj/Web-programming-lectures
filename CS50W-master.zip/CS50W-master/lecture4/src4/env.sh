export DATABASE_URL="postgres://localhost/lecture4"
