i = 28
print(f"i is {i}")

f = 2.8
print(f"f is {f}")

b = True
print(f"b is {b}")

n = None
print(f"n is {n}")
